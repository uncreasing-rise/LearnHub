﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Entities.V1
{
    internal class Student
    {
        private string _id;// quy tắc đặt tên cho đặt tính 
        private string _name;  //của một object:_kem camel Case Notation
        private string _email;// mô tả đặt tính của 1 object
        private int _yob;    // được gọi là backed-field, backing field, field
        private double _gpa; //Java gọi là property/attribute/ characteristic

        public Student(string id, string name, string email, int yob, double gpa)
        {
            _id = id;
            _name = name;
            _email = email;
            _yob = yob;
            _gpa = gpa;
        }

        //constructer: hàm, phễu nhận thông tin bên ngoài, vật liệu bên ngoài đổ lấp vào các ngóc ngách, đặc tính bên trong khuôn của Class

        //Tên hàm tạo ra đối tượng/tên constructer 100% giống tên Class
        //Nó là cái phễu hứng info bên ngoài đưa vào trong
        //Ctr .

        //mặc định các info của các object là private
        //vậy nếu muốn cho người khác biết, thì ta đưa ra cách giao tiếp
        //hỏi đáp, bạn hỏi tôi đáp, bạn muốn biết hãy hỏi tôi, GetInfo của tôi - > hàm Get() xuất hiện
        public string GetName()
        {
            return _name;
        }
        //kiểu truyền thống

        public string GetEmail() => _email;
        //expression body khi hàm chỉ có 1 lệnh duy nhất

        //tương tự cho các hàm Get() còn lại...

        //KHI CÓ NHU CẦU CHỈNH SỬA/UPDATE/EDIT INFO CỦA OBJECT
        //HOẶC MÀI GIŨA TINH CHỈNH BỨC TƯỢNG ĐƯỢC ĐÚC RA, TA CÓ HÀNH ĐỘNG
        //SET(), SETTING()
        //Set() thiết lập thông tin mới  đồng nhĩa phải đưa thông tin mới vào đè/overwrite thông tin cũ
        public void SetGpa(double gpa)
        {
            _gpa = gpa;
        }
        //truyền thống

        public void SetYob(int yob) => _yob = yob;
        //expression body

        //hành động show projile giống như trên FB MXH
        public void ShowProfile()
        {
            Console.WriteLine(@$"Here is my info:
ID:{_id}
Name: {_name}
Email: {_email}
Yob: {_yob}
Gpa:{_gpa}");
        }
    }
}
