﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Entities.V2
{
    internal class Student
    {
        private string _id;         //Biến dùng để lưu các info của 1 obj
        private string _name;       //nào đó sẽ được tạo ra bởi new
        private string _email;      //BIẾN BẮT BUỘC PHẢI GỌI TÊN MỚI LÀ
        private int _yob;           //backing field
        private double _gpa;        //BACKING FIELD VÀ METHOD GỌI CHUNG LÀ MEMEBERS OF A CLASS, NHỮNG THÀNH PHẦN TẠO NÊN CLASS
                                    //BIẾN/bACKING FIELD DÙNG ĐỂ LƯU TRẠNG THÁI CỦA OBJECT - STATE. TRẠNG THÁI CỦA SV TUI LÀ SN 2K3 , ĐIỂM CỦA TÔI LÀ 8
                                    //1 CLASS NẾU KHÔNG TẠO CONSTRUCTOR, VẪN TẠO OBJECT VỚI 
                                    //STATE LÀ DEFAULT
                                    // CHUỖI -> RỖNG
                                    // SỐ -> 0
                                    //BOOL -> FALSE
                                    //VẪN NEW BÌNH THƯỜNG, KHI ĐÓ RUNTIME ENV SẼ TỰ TẠO RA CHO 1 PHỄU DEFAULT, CONSTRUCTOR, KHÔNG ĐẦU VÀO, KHÔNG CÂU LỆNH
        //public Student()
        //{
            
        //}

        public int GetYob() => _yob;
    }
}
