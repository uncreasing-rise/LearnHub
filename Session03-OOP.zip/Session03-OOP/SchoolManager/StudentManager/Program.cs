﻿using StudentManager.Entities.V1;
using StudentManager.Entities.V2;

namespace StudentManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            //CreateObjectV1();// tạo object kiểu truyền thống
            //CreateObjectV2();// lược bỏ tên class ở new
            // do đã khai báo rồi Student dat=
            //CreateObjectV3(); // dùng var, nhưng vế new bên kia phải ghi rõ datatype cho var là gì!!!
            //CreateObjectV4();// named argument, tên tham số đi kèm value
            CreateObjectV5();
        }

        static void CreateObjectV5()
        {
            StudentManager.Entities.V2.Student s = new StudentManager.Entities.V2.Student();

            Console.WriteLine("Yob: "+ s.GetYob());// 0 default
            int yob;
            Console.WriteLine();
        }





        //static void CreateObjectV4()
        //{

        //    var dat = new Student(id:"SE1",name: "Đạt Trần Tấn", email: "datttse171128@fpt.edu.vn", gpa: 8, yob: 2003);

        //    dat.ShowProfile();
        //}//ta ghi tên đầu vào của hàm kèm dấu 2 chám để định danh tến biến sẽ nhận đầu vào
        ////new kiểu này cho phép ta dùng lộn xộn thứ tự truyền vào
        ////named-argument: pass value to a method accompany with the
        ////variable ame. Do net need to follow the parameter order strictly






        //static void CreateObjectV3()
        //{

        //    var dat = new Student("SE1", "Đạt Trần Tấn", "datttse171128@fpt.edu.vn", 2003, 8);

        //    dat.ShowProfile();
        //}




        //static void CreateObjectV2()
        //{
           
        //    Student dat = new ("SE1", "Đạt Trần Tấn", "datttse171128@fpt.edu.vn", 2003, 8);

        //    dat.ShowProfile();
        //}





        ////tạo object từ Class, đúc tượng từ khuôn
        //static void CreateObjectV1() 
        //{
        //    //một object chứa nhiều info - complex
        //    //ta luôn đặt tên gọi cho mọi thứ quanh ta, object cũng vậy. Bạn sv Trần Tấn Đạt, SN 2K3, Bình Dương, Việt Nhật
        //    // ta gọi tắt là đạt (camel case)
        //    Student dat =  new Student("SE1", "Đạt Trần Tấn","datttse171128@fpt.edu.vn", 2003, 8);
        //    //dat: biến object -obj variable
        //    //new Student(...) là objec, là những gì cụ thể tồn tại quanh chúng ta. Bạn SV Đạt với đầy đủ info ở trên là có thật, cụ thể
        //    //2 vùng ram được cấp
        //    //new Student(...) - > nằm trên vùng nhớ HEAP

        //    dat.ShowProfile();
        //}
    }
}
